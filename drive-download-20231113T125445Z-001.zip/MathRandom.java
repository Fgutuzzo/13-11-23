public class MathRandom {
    public static void main(String[] args) {
        System.out.println(Math.random());  
    }
}
