public class StringAndIntegerConcatenation {
    public static void main(String[] args) {
        String x = "10";
        int y = 20;
        String z = x + y;
        System.out.println(z);
    }
}
