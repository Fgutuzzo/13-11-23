public class IntegrarLater {
  public static void main(String[] args) {
    int myNum;
    myNum = 15;
    System.out.println(myNum);
  }
}
