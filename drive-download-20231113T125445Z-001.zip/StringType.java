public class StringType {
    public static void main(String[] args) {
        String greeting = "Hello World";
        System.out.println(greeting);
    }
}
