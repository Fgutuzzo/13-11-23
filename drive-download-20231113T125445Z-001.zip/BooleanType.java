public class BooleanType {
    public static void main(String[] args) {
        boolean isJavaFun = true;
        boolean isFishTasty = false;    
        System.out.println(isJavaFun);
        System.out.println(isFishTasty);
    }
}
