public class MathSquare {
    public static void main(String[] args) {
        System.out.println(Math.sqrt(64));  
    }
}
