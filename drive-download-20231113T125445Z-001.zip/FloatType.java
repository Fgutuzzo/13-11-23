public class FloatType {
    public static void main(String[] args) {
        float myNum = 5.75f;
        System.out.println(myNum);  
    }
}
