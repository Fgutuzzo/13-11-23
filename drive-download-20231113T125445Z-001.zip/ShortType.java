public class ShortType {
    public static void main(String[] args) {
        short myNum = 5000;
        System.out.println(myNum);  
    }
}
