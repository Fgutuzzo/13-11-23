public class DoubleType {
    public static void main(String[] args) {
        double myNum = 19.99d;
        System.out.println(myNum);  
    }
}
