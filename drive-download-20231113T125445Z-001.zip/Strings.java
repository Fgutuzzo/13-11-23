public class Strings {
  public static void main(String[] args) {
    String name = "John";
    System.out.println(name);
  }
}