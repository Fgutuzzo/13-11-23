public class AddVarIntoOtherVar {
    public static void main(String[] args) {
        String firstName = "John ";
        String lastName = "Doe";
        String fullName = firstName + lastName;
        System.out.println(fullName);  
      }
}
