public class Integer {
  public static void main(String[] args) {
    int myNum = 15;
    System.out.println(myNum);
  }
}