public class CombineStringAndVariable {
    public static void main(String[] args) {
        String name = "John";
        System.out.println("Hello " + name);
    }
}
