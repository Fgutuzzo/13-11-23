public class IntegerType {
    public static void main(String[] args) {
        int myNum = 100000;
        System.out.println(myNum);  
    }
}
