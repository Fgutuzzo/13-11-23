public class MathMin {
    public static void main(String[] args) {
        System.out.println(Math.min(5, 10));  
    }
}
