public class LongType {
    public static void main(String[] args) {
        long myNum = 15000000000L;
        System.out.println(myNum);  
      }
}
