public class MathMax {
    public static void main(String[] args) {
        System.out.println(Math.max(5, 10));  
    }
}
