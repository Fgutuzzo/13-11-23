public class CharType {
    public static void main(String[] args) {
        char myGrade = 'B';
        System.out.println(myGrade);
    }
}
