public class MathAbsolute {
    public static void main(String[] args) {
        System.out.println(Math.abs(-4.7));  
      }
}
