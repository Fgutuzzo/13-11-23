public class CommaIntegers {
    public static void main(String[] args) {
        int x = 5, y = 6, z = 50;
        System.out.println(x + y + z);
    }
}
